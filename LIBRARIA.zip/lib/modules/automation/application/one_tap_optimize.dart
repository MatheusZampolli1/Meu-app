﻿import 'dart:async';
import 'dart:developer' as developer;
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';

import 'package:game_master_plus/modules/dashboard/data/metric_history_repository.dart';
import 'package:game_master_plus/modules/security/data/security_event_repository.dart';
import 'package:game_master_plus/services/system_services.dart';
import 'package:game_master_plus/shared/perf/performance_profile.dart';
import 'package:game_master_plus/shared/perf/perf_native.dart';

const _logName = 'OneTapOptimize';
const MethodChannel _perfChannel = MethodChannel('fluxon/perf');

Future<void> runOneTapOptimize(BuildContext context) async {
  const totalSteps = 5;
  var dialogTitle = 'Otimizando...';
  var dialogMessage = 'Otimizando... (passo 0/$totalSteps)';
  var showProgress = true;
  var allowClose = false;

  final failedSteps = <String>[];
  final messenger = ScaffoldMessenger.maybeOf(context);
  final theme = Theme.of(context);

  final dialogReady = Completer<void>();
  final dialogClosed = Completer<void>();
  StateSetter? dialogSetState;

  unawaited(
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return WillPopScope(
          onWillPop: () async => allowClose,
          child: StatefulBuilder(
            builder: (dialogInnerContext, setState) {
              dialogSetState = setState;
              if (!dialogReady.isCompleted) {
                dialogReady.complete();
              }
              return AlertDialog(
                title: Text(dialogTitle),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (showProgress) const CircularProgressIndicator(),
                    if (showProgress) const SizedBox(height: 16),
                    Text(
                      dialogMessage,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
                actions: allowClose
                    ? [
                        TextButton(
                          onPressed: () => Navigator.of(dialogContext, rootNavigator: true).pop(),
                          child: const Text('Concluir'),
                        ),
                      ]
                    : null,
              );
            },
          ),
        );
      },
    ).then((_) {
      if (!dialogClosed.isCompleted) {
        dialogClosed.complete();
      }
    }),
  );

  await dialogReady.future;

  void updateDialog({
    String? message,
    String? title,
    bool? progress,
    bool? canClose,
  }) {
    if (dialogSetState == null) {
      return;
    }
    dialogSetState!(() {
      if (message != null) {
        dialogMessage = message;
      }
      if (title != null) {
        dialogTitle = title;
      }
      if (progress != null) {
        showProgress = progress;
      }
      if (canClose != null) {
        allowClose = canClose;
      }
    });
  }

  Future<Box<Map<String, dynamic>>> ensureBox(String name) async {
    if (Hive.isBoxOpen(name)) {
      return Hive.box<Map<String, dynamic>>(name);
    }
    return Hive.openBox<Map<String, dynamic>>(name);
  }

  final securityRepo = SecurityEventRepository(
    await ensureBox(SecurityEventRepository.boxName),
  );
  final metricsService = SystemMetricsService();

  Future<void> logError(String stepLabel, Object error, StackTrace stackTrace) async {
    developer.log(
      'Failed during $stepLabel',
      name: _logName,
      error: error,
      stackTrace: stackTrace,
    );
    try {
      await securityRepo.addEvent(
        type: 'automation_error',
        title: 'Erro na otimizacao',
        message: 'Falhou em $stepLabel',
        meta: {
          'step': stepLabel,
          'error': error.toString(),
        },
      );
    } catch (repoError, repoStack) {
      developer.log(
        'Failed to record automation error',
        name: _logName,
        error: repoError,
        stackTrace: repoStack,
      );
    }
  }

  Future<void> executeStep({
    required int index,
    required String label,
    required Future<void> Function() action,
  }) async {
    updateDialog(
      message: 'Otimizando... (passo $index/$totalSteps)\n$label',
      title: 'Otimizando...',
      progress: true,
      canClose: false,
    );
    try {
      await action();
    } catch (error, stackTrace) {
      final failureLabel = 'passo $index - $label';
      failedSteps.add(failureLabel);
      await logError(failureLabel, error, stackTrace);
    }
  }

  Future<void> clearTemporaryFiles() async {
    final tempDir = await getTemporaryDirectory();
    if (!await tempDir.exists()) {
      return;
    }

    final failures = <String>[];
    await for (final entity in tempDir.list(followLinks: false)) {
      try {
        if (entity is File || entity is Link) {
          await entity.delete();
        } else if (entity is Directory) {
          await entity.delete(recursive: true);
        }
      } catch (_) {
        failures.add(entity.path);
      }
    }

    if (failures.isNotEmpty) {
      throw FileSystemException(
        'Falha ao limpar diretorios temporarios',
        failures.join(', '),
      );
    }
  }

  Future<void> recordMetricsSnapshot() async {
    final metrics = await metricsService.fetchMetrics();
    final box = await ensureBox(MetricHistoryRepository.boxName);
    final repository = MetricHistoryRepository(box);
    await repository.addSnapshot(metrics);
  }

  Future<bool> isIgnoringBatteryOptimizations() async {
    try {
      final result = await _perfChannel.invokeMethod<bool>('isIgnoringBatteryOpt');
      return result ?? false;
    } on MissingPluginException {
      return false;
    } catch (error, stackTrace) {
      developer.log(
        'Unable to verify battery optimization status',
        name: _logName,
        error: error,
        stackTrace: stackTrace,
      );
      return false;
    }
  }

  await executeStep(
    index: 1,
    label: 'Aplicando perfil Turbo',
    action: () async {
      await PerfController().setProfile(PerfProfile.turbo);
    },
  );

  await executeStep(
    index: 2,
    label: 'Ativando modo Turbo nativo',
    action: () async {
      await PerfNative.startTurbo();
    },
  );

  await executeStep(
    index: 3,
    label: 'Limpando arquivos temporarios do app',
    action: clearTemporaryFiles,
  );

  await executeStep(
    index: 4,
    label: 'Registrando snapshot de metricas',
    action: recordMetricsSnapshot,
  );

  await executeStep(
    index: 5,
    label: 'Solicitando ignorar otimizacao de bateria',
    action: () async {
      if (await isIgnoringBatteryOptimizations()) {
        return;
      }
      await PerfNative.requestIgnoreBatteryOpt();
    },
  );

  if (failedSteps.isEmpty) {
    updateDialog(
      title: 'Tudo pronto',
      message: 'O celular foi otimizado!',
      progress: false,
      canClose: true,
    );
    try {
      await securityRepo.addEvent(
        type: 'automation',
        title: 'Otimizacao concluida',
        message: 'One Tap Optimize executado com sucesso',
      );
    } catch (error, stackTrace) {
      developer.log(
        'Failed to record automation success',
        name: _logName,
        error: error,
        stackTrace: stackTrace,
      );
    }
    messenger?.clearSnackBars();
    messenger?.showSnackBar(
      const SnackBar(content: Text('O celular foi otimizado!')),
    );
  } else {
    final detail = failedSteps.join(', ');
    updateDialog(
      title: 'Otimizacao incompleta',
      message: 'Falhou em $detail',
      progress: false,
      canClose: true,
    );
    try {
      await securityRepo.addEvent(
        type: 'automation_error',
        title: 'Otimizacao incompleta',
        message: 'Falhou em $detail',
        meta: {'falhas': detail},
      );
    } catch (error, stackTrace) {
      developer.log(
        'Failed to record aggregated automation error',
        name: _logName,
        error: error,
        stackTrace: stackTrace,
      );
    }
    messenger?.clearSnackBars();
    messenger?.showSnackBar(
      SnackBar(
        content: Text('Falhou em $detail'),
        backgroundColor: theme.colorScheme.error,
      ),
    );
  }

  await dialogClosed.future;
}
