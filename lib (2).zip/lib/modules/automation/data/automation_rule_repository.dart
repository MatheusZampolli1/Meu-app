import 'package:hive/hive.dart';

import 'package:game_master_plus/modules/automation/domain/automation_rule.dart';

class AutomationRuleRepository {
  const AutomationRuleRepository(this._box);

  static const String boxName = 'automation_rules';

  final Box<dynamic> _box;

  List<AutomationRule> getAll() {
    return _box.values
        .whereType<Map>()
        .map((value) => AutomationRule.fromMap(Map<String, dynamic>.from(value as Map)))
        .toList(growable: false);
  }

  Future<void> upsertRule(AutomationRule rule) async {
    final existingKey = _findKey(rule.id);
    if (existingKey != null) {
      await _box.put(existingKey, rule.toMap());
    } else {
      await _box.add(rule.toMap());
    }
  }

  Future<void> deleteRule(String ruleId) async {
    final key = _findKey(ruleId);
    if (key != null) {
      await _box.delete(key);
    }
  }

  Future<void> clear() async => _box.clear();

  dynamic _findKey(String id) {
    for (final key in _box.keys) {
      final rawValue = _box.get(key);
      if (rawValue is Map) {
        final value = Map<String, dynamic>.from(rawValue as Map);
        if (value['id'] == id) {
          return key;
        }
      }
    }
    return null;
  }
}

