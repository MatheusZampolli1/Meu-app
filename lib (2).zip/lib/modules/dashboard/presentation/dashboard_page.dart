import 'dart:async';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:flutter_lucide/flutter_lucide.dart';

import 'package:game_master_plus/l10n/app_localizations.dart';
import 'package:game_master_plus/modules/dashboard/application/insights_service.dart';
import 'package:game_master_plus/modules/dashboard/data/metric_history_repository.dart';
import 'package:game_master_plus/modules/dashboard/domain/metric_insight.dart';
import 'package:game_master_plus/modules/dashboard/presentation/widgets/metrics_chart.dart';
import 'package:game_master_plus/services/system_services.dart';
import 'package:game_master_plus/shared/theme/app_theme.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final SystemMetricsService _metricsService = SystemMetricsService();
  late final MetricHistoryRepository _historyRepository;
  late final InsightsService _insightsService;

  DeviceMetrics _metrics = DeviceMetrics.initial();
  List<MetricInsight> _insights = const [];
  StreamSubscription<DeviceMetrics>? _subscription;
  bool _heroVisible = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _historyRepository = MetricHistoryRepository(
      Hive.box(MetricHistoryRepository.boxName),
    );
    _insightsService = InsightsService();
    _loadMetrics();
    _subscription = _metricsService.metricsStream().listen(_processMetrics);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        setState(() => _heroVisible = true);
      }
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  Future<void> _loadMetrics() async {
    try {
      final metrics = await _metricsService.fetchMetrics();
      await _processMetrics(metrics);
    } catch (error) {
      if (!mounted) return;
      setState(() => _errorMessage = error.toString());
    }
  }

  Future<void> _processMetrics(DeviceMetrics metrics) async {
    try {
      await _historyRepository.addSnapshot(metrics);
    } catch (error) {
      if (!mounted) return;
      setState(() => _errorMessage = error.toString());
    }

    final history = _historyRepository.recent(limit: 32);
    if (!mounted) return;

    final l10n = AppLocalizations.of(context)!;
    final insights = _insightsService.buildInsights(
      latest: metrics,
      history: history,
      l10n: l10n,
    );

    if (!mounted) return;
    setState(() {
      _metrics = metrics;
      _insights = insights;
    });
  }

  Color _statusColor(double value) {
    if (value >= 85) return Colors.redAccent;
    if (value >= 65) return Colors.orangeAccent;
    return Colors.lightGreenAccent;
  }

  Color _storageColor(double value) {
    if (value <= 8) return Colors.redAccent;
    if (value <= 16) return Colors.orangeAccent;
    return Colors.lightGreenAccent;
  }

  Color _batteryColor(int value) {
    if (value <= 20) return Colors.redAccent;
    if (value <= 40) return Colors.orangeAccent;
    return Colors.lightGreenAccent;
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final accent = theme.colorScheme.primary;

    return RefreshIndicator(
      color: accent,
      onRefresh: _loadMetrics,
      child: ListView(
        padding: const EdgeInsets.symmetric(vertical: 12),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
            child: _DashboardHero(
              message: l10n.dashboardHeroMessage,
              visible: _heroVisible,
            ),
          ),
          if (_errorMessage != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _ErrorBanner(message: _errorMessage!),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: const MetricsChart(),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
            child: Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [
                _MetricSummaryCard(
                  icon: LucideIcons.gauge,
                  title: l10n.metricCpuTitle,
                  value: '${_metrics.cpuUsage.toStringAsFixed(0)}%',
                  subtitle: l10n.metricCpuSubtitle,
                  indicatorColor: _statusColor(_metrics.cpuUsage),
                ),
                _MetricSummaryCard(
                  icon: LucideIcons.memory_stick,
                  title: l10n.metricRamTitle,
                  value: '${_metrics.ramUsage.toStringAsFixed(0)}%',
                  subtitle: l10n.metricRamSubtitle,
                  indicatorColor: _statusColor(_metrics.ramUsage),
                ),
                _MetricSummaryCard(
                  icon: LucideIcons.database,
                  title: l10n.metricStorageTitle,
                  value: '${_metrics.storageFree.toStringAsFixed(0)} GB',
                  subtitle: l10n.metricStorageSubtitle,
                  indicatorColor: _storageColor(_metrics.storageFree),
                ),
                _MetricSummaryCard(
                  icon: LucideIcons.thermometer_sun,
                  title: l10n.metricTemperatureTitle,
                  value: '${_metrics.temperature.toStringAsFixed(1)} C',
                  subtitle: l10n.metricTemperatureSubtitle,
                  indicatorColor: _statusColor(_metrics.temperature),
                ),
                _MetricSummaryCard(
                  icon: LucideIcons.battery_charging,
                  title: l10n.metricBatteryTitle,
                  value: '${_metrics.batteryLevel}%',
                  subtitle: l10n.metricBatterySubtitle,
                  indicatorColor: _batteryColor(_metrics.batteryLevel),
                ),
              ],
            ),
          ),
          if (_insights.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _InsightsSection(insights: _insights),
            ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }
}

class _ErrorBanner extends StatelessWidget {
  const _ErrorBanner({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        color: theme.colorScheme.error.withOpacity(0.12),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: theme.colorScheme.error.withOpacity(0.4)),
      ),
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(LucideIcons.triangle_alert, color: theme.colorScheme.error),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              message,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onErrorContainer,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricSummaryCard extends StatelessWidget {
  const _MetricSummaryCard({
    required this.icon,
    required this.title,
    required this.value,
    required this.subtitle,
    required this.indicatorColor,
  });

  final IconData icon;
  final String title;
  final String value;
  final String subtitle;
  final Color indicatorColor;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SizedBox(
      width: 260,
      child: Semantics(
        label: '$title: $value',
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                indicatorColor.withOpacity(0.18),
                theme.colorScheme.surfaceVariant.withOpacity(0.2),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: indicatorColor.withOpacity(0.45)),
          ),
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: indicatorColor.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.all(12),
                    child: Icon(icon, color: indicatorColor, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      title,
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                value,
                style: theme.textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
class _InsightsSection extends StatelessWidget {
  const _InsightsSection({required this.insights});

  final List<MetricInsight> insights;

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.primary;
    return AnimatedSwitcher(
      duration: FluxonTheme.mediumAnimation,
      child: Column(
        key: ValueKey(insights.length),
        children: insights
            .map((insight) => Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: _InsightCard(insight: insight, accent: accent),
                ))
            .toList(),
      ),
    );
  }
}

class _InsightCard extends StatelessWidget {
  const _InsightCard({required this.insight, required this.accent});

  final MetricInsight insight;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final severityColor = _colorForSeverity(insight.severity, colorScheme, accent);
    final icon = _iconForSeverity(insight.severity);

    return Container(
      decoration: BoxDecoration(
        color: FluxonTheme.cardColor.withOpacity(0.85),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: severityColor.withOpacity(0.45)),
        boxShadow: [
          BoxShadow(
            color: severityColor.withOpacity(0.18),
            blurRadius: 18,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      padding: const EdgeInsets.all(20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
              color: severityColor.withOpacity(0.16),
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(12),
            child: Icon(icon, color: severityColor, size: 20),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  insight.title,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(color: Colors.white, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 8),
                Text(
                  insight.message,
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(color: Colors.white70),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Color _colorForSeverity(InsightSeverity severity, ColorScheme scheme, Color accent) {
    switch (severity) {
      case InsightSeverity.critical:
        return Colors.redAccent;
      case InsightSeverity.warning:
        return Colors.orangeAccent;
      case InsightSeverity.info:
        return scheme.secondary;
      case InsightSeverity.positive:
        return accent;
    }
  }

  static IconData _iconForSeverity(InsightSeverity severity) {
    switch (severity) {
      case InsightSeverity.critical:
        return LucideIcons.shield_alert;
      case InsightSeverity.warning:
        return LucideIcons.triangle_alert;
      case InsightSeverity.info:
        return LucideIcons.info;
      case InsightSeverity.positive:
        return LucideIcons.badge_check;
    }
  }
}

class _DashboardHero extends StatelessWidget {
  const _DashboardHero({required this.message, required this.visible});

  final String message;
  final bool visible;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accent = theme.colorScheme.primary;

    return AnimatedOpacity(
      duration: FluxonTheme.longAnimation,
      opacity: visible ? 1 : 0,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [accent, accent.withOpacity(0.6)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: accent.withOpacity(0.35),
              blurRadius: 24,
              offset: const Offset(0, 18),
            ),
          ],
        ),
        padding: const EdgeInsets.all(24),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(18),
              ),
              padding: const EdgeInsets.all(14),
              child: const Icon(LucideIcons.sparkles, color: Colors.white, size: 28),
            ),
            const SizedBox(width: 20),
            Expanded(
              child: Text(
                message,
                style: theme.textTheme.titleLarge?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

